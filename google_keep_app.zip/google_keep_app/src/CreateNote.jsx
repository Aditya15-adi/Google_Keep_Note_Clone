import React, { useState } from 'react';
import Button from '@material-ui/core/Button'
import Add from '@material-ui/icons/Add'


const CreateNote = (props) => {
    const [note,setnote]=useState({title:"",content:""});
    const [expand,setexpand]=useState(false);
    const ipevent=(event)=>{
        const {name,value}=event.target;

        setnote ((preval)=>{
            return{
                ...preval,
                [name]:value,
            }
        })
    }
    }
    const addevent=()=>{
        props.passnote(note);
        setnote({title:"",content:""})
        setexpand(false);
    }
    const dis=()=>{
        setexpand(true)
    }
    return (
        <>
            <div className="createnote">
                <form action="">
                    <input type="text"
                        placeholder='Title' autoComplete='off'
                        name='title'
                        value={note.title}
                        onChange={ipevent}
                       
                    /><br />
                    <textarea
                        cols="30" rows="5"
                        placeholder='Write a Note...'
                        name='content'
                        value={note.content}
                        onChange={ipevent}
                        onClick={dis}
                        
                    ></textarea><br />
                    {expand?
                    <Button id='sub' onClick={addevent}><Add /></Button>:null}

                </form>
            </div>
        </>
    )
}
export default CreateNote;

/* CSS:-
    .createnote{
    border: 2px solid black;
    width: 400px;
    margin-left: 377px;
    margin-top: 25px;
    padding-left: 30px;
    padding-top: 20px;
    }
    input{
  border:none;
  text-align: left;
  border-bottom: 1px solid orange;
  margin-top: 15px;
  box-shadow: 2px solid black;
} 
textarea{
  border:none;
  text-align: left;
  margin-top: 40px;
}
#sub{
  margin-left: 300px;
  background-color: rgb(252, 242, 224);
  margin-top: 20px;
  margin-bottom: 20px;
}
*/