import React from 'react';
import logo from './logo.jpg'

const Header=()=>{
    return(
        <>
            <div className="header">
                <img src={logo} alt="" width='50' height='60' />
                <h1> Google Keep Notes</h1>
                </div>        
        </>
    );
}

export default  Header;