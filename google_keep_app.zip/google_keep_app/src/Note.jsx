import React from "react"
import Button from '@material-ui/core/Button'
import Delete from '@material-ui/icons/DeleteOutline'


const Note=(props)=>{
    const removeitem=()=>{
            props.deleteitem(props.id);
    }
    
    return(
        <>
            <div className="card">
            <h1 id="title">{props.title}</h1>
            <p id="content">{props.content}</p>
            <Button id="del" onClick={removeitem}><Delete/></Button>

            </div>
        </>
    )
}
export default Note;