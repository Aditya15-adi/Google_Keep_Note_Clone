import React from 'react';

const Footer=()=>{
    const  year =new Date().getFullYear()
    return(
        <>
            <div className="footer">
                <p>copyright © {year}</p>
            </div>
        </>
    )
}
export default Footer;


/*
  CSS:-
.footer{
  position: absolute;
    bottom: 0;
    left: 525px;
    height: 34px;
    bottom: 20px;
} */